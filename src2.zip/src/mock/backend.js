export const BackEndConfig = {
  link: "http://localhost:3030/",
};
