import styled from "styled-components";

const LibraryRoot = styled.div`
  color: #212121;
`;

export { LibraryRoot };
